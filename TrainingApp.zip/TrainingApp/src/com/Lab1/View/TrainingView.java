package com.Lab1.View;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

// This is the View
// Its only job is to display what the user sees
// It performs no calculations, but instead passes
// information entered by the user to whomever needs it
public class TrainingView extends JFrame{

    private JLabel welcomeTextLabel = new JLabel("Welcome Stranger! What is your name?");
    private JTextField getNameField = new JTextField(10);
    private JButton sendNameButton = new JButton("Send");
    private JLabel showNameLabel = new JLabel("");

    public TrainingView(){
        // Sets up the view and adds the components
        super("Training App");
        JPanel trainPanel = new JPanel();

        setFrameDefaults(260,200);

        trainPanel.add(welcomeTextLabel);
        trainPanel.add(getNameField);
        trainPanel.add(sendNameButton);
        trainPanel.add(showNameLabel);

        this.add(trainPanel);

        // End of setting up the components --------
    }

    private void setFrameDefaults(int sizeX, int sizeY){

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(sizeX, sizeY);
        this.setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2,Toolkit.getDefaultToolkit().getScreenSize().height/2);
        this.setLayout(new GridLayout(2,1));
    }

    public String getNameFromField(){

        return getNameField.getText();
    }

    public void setShowNameField(String name){

        showNameLabel.setText("Hello " + name + " :)");
    }

    // If the sendNameButton is clicked execute a method
    // in the Controller named actionPerformed

    public void addNameListener(ActionListener listenForNameButton){

        sendNameButton.addActionListener(listenForNameButton);
    }

    // Open a popup that contains the error message passed
    public void displayErrorMessage(String errorMessage){

        JOptionPane.showMessageDialog(this, errorMessage);
    }


}
