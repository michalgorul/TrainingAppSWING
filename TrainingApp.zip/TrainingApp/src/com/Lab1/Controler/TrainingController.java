package com.Lab1.Controler;

import com.Lab1.Model.TrainingModel;
import com.Lab1.View.TrainingView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// The Controller coordinates interactions
// between the View and Model
public class TrainingController {

    private TrainingView theView;
    private TrainingModel theModel;

    public TrainingController(TrainingView theView, TrainingModel theModel){

        this.theView = theView;
        this.theModel = theModel;

        // Tell the View that when ever the send button
        // is clicked to execute the actionPerformed method
        // in the NameListener inner class
        this.theView.addNameListener(new NameListener());
    }

    class NameListener implements ActionListener{

        //@Override
        public void actionPerformed(ActionEvent e) {

            String name = "";

            // Surround interactions with the view with
            // a try block in case name wasn't properly entered
            try{
                name = theView.getNameFromField();
                theModel.setUserName(name);
                theView.setShowNameField(theModel.getUserName());
            }
            catch(NullPointerException ex){
                theView.displayErrorMessage("You need to enter a name");
            }
        }
    }

}
