package com.Lab1.MVC;

import com.Lab1.Controler.TrainingController;
import com.Lab1.Model.TrainingModel;
import com.Lab1.View.TrainingView;

public class MVCTraining {
    public static void main(String[] args) {

        System.out.println("hello");

        TrainingView theView = new TrainingView();
        TrainingModel theModel = new TrainingModel();
        TrainingController theController = new TrainingController(theView, theModel);

        theView.setVisible(true);
    }
}
