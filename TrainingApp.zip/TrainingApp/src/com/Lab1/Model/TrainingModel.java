package com.Lab1.Model;

// The Model performs all the calculations and data needed
// and that is it. It doesn't know the View
// exists
public class TrainingModel {

    // Holds the string of the user's name
    // entered in the view
    private String userName;

    public void setUserName(String userName){
        this.userName = userName;
    }

    public String getUserName(){
        return this.userName;
    }
}
